import 'package:aura_estates_core/aura_estates_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'booking_repository.g.dart';

// On expose le repository via Riverpod pour pouvoir l'injecter
@riverpod
BookingRepository bookingRepository(Ref ref) {
  return BookingRepository();
}

class BookingRepository {
  // On cible directement la collection Firestore
  final CollectionReference _collection = FirebaseFirestore.instance.collection(
    'Booking requests',
  );

  // 📋 Récupère toutes les demandes
  Future<List<BookingModel>> fetchAll() async {
    final snapshot = await _collection.get();
    return snapshot.docs
        .map(
          (doc) =>
              BookingModel.fromJson(doc.data() as Map<String, dynamic>, doc.id),
        )
        .toList();
  }

  // 📋 Surveille toutes les demandes
  Stream<List<BookingModel>> watchBookings() {
    return _collection.snapshots().map(
      (snapshot) => snapshot.docs
          .map(
            (doc) => BookingModel.fromJson(
              doc.data() as Map<String, dynamic>,
              doc.id,
            ),
          )
          .toList(),
    );
  }

  // ➕ Ajoute un nouveau véhicule
  Future<void> add(BookingModel bookingRequest) async {
    await _collection.add(bookingRequest.toJson());
  }

  // 🗑️ Supprime un véhicule
  Future<void> delete(String id) async {
    await _collection.doc(id).delete();
  }
}
