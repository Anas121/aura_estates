import 'package:aura_estates_core/aura_estates_core.dart';

class BookingModel {
  final String id; // l'id réel du document Firestore (vide à la création)
  final String userName;
  final String userMail;
  final String userPhone;
  final String bookingDate;
  final PropertyModel currentProperty;

  BookingModel({
    this.id = '',
    required this.currentProperty,
    required this.userName,
    required this.userMail,
    required this.userPhone,
    required this.bookingDate,
  });

  factory BookingModel.fromJson(Map<String, dynamic> json, String id) {
    return BookingModel(
      id: id,
      currentProperty: json['currentProperty'] as PropertyModel,
      userName: json['userName'] as String? ?? 'Inconnue',
      userMail: json['userMail'] as String? ?? 'Inconnue',
      userPhone: json['userPhone'] as String? ?? 'Inconnue',
      bookingDate: json['bookingDate'] as String? ?? 'Inconnue',
    );
  }

  // 📤 Dart → Firestore
  Map<String, dynamic> toJson() {
    return {
      'currentProperty': currentProperty,
      'userName': userName,
      'userMail': userMail,
      'userPhone': userPhone,
      'bookingDate': bookingDate,
    };
  }
}
