import 'package:aura_estates_core/aura_estates_core.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'booking_controller.g.dart';

@riverpod
Stream<List<BookingModel>> bookingsStream(Ref ref) {
  return ref.watch(bookingRepositoryProvider).watchBookings();
}

@riverpod
class BookingController extends _$BookingController {
  @override
  Future<List<BookingModel>> build() async {
    // On demande au Repository de récupérer les données
    return ref.read(bookingRepositoryProvider).fetchAll();
  }

  Future<void> addBookingRequest(BookingModel bookingRequest) async {
    state = const AsyncLoading();
    await AsyncValue.guard(() async {
      await ref.read(bookingRepositoryProvider).add(bookingRequest);
    });

    ref.invalidateSelf();
  }

  // 🗑️ Action : supprimer un véhicule
  Future<void> deleteBookingRequest(String id) async {
    state = const AsyncLoading();
    await AsyncValue.guard(() async {
      await ref.read(bookingRepositoryProvider).delete(id);
    });
    ref.invalidateSelf();
  }
}
