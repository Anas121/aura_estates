import 'package:admin/features/pages/bookings/bookings_page.dart';
import 'package:admin/features/pages/components/admin_sidebar.dart';
import 'package:admin/features/pages/dashboard/reservations_table.dart';
import 'package:admin/features/pages/properties/properties_page.dart';
import 'package:aura_estates_core/aura_estates_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:google_fonts/google_fonts.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedIndex = 0;
  final List<Widget> _pages = const [
    DashboardBody(), // index 0 — Tableau de bord
    PropertiesPage(), // index 1 — Propriétés
    BookingsPage(), // index 2 — Réservations
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.noir,
      body: Row(
        children: [
          //--- SIDE BAR ---
          AdminSidebar(
            selectedIndex: _selectedIndex,
            onDestinationSelected: (i) => setState(() => _selectedIndex = i),
          ),
          const VerticalDivider(width: 0.5, color: AppColors.surfaceElevee),
          Expanded(child: _pages[_selectedIndex]),
        ],
      ),
    );
  }
}

class DashboardBody extends ConsumerStatefulWidget {
  const DashboardBody({super.key});

  @override
  ConsumerState<DashboardBody> createState() => _DashboardBodyState();
}

class _DashboardBodyState extends ConsumerState<DashboardBody> {
  //--- Prend les 5 dérnieres demandes ----
  List<BookingModel> getLastRequests(List<BookingModel> requests) {
    return requests.take(5).toList();
  }

  @override
  Widget build(BuildContext context) {
    final asyncBooking = ref.watch(bookingsStreamProvider);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 5),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Tableau de bord',
                style: GoogleFonts.cormorantGaramond(
                  fontSize: 23,
                  fontWeight: FontWeight.w600,
                  fontStyle: FontStyle.italic,
                  color: AppColors.textPrimaire,
                ),
              ),
              Text(
                DateTime.now().toLocal().toString().split(' ')[0],
                style: GoogleFonts.jost(
                  fontSize: 15,
                  color: AppColors.textSecondaire,
                ),
              ),
            ],
          ),
        ),
        const Divider(color: AppColors.bordure),

        // -----------    BODY    ---------------
        Expanded(
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: ListView(
              children: [
                Text(
                  'Dernières réservations',
                  style: GoogleFonts.jost(
                    color: AppColors.textPrimaire,
                    fontSize: 14,
                    letterSpacing: -0.2,
                  ),
                ),

                const SizedBox(height: 10),
                asyncBooking.when(
                  data: (data) {
                    return ReservationsTable(requests: getLastRequests(data));
                  },
                  error: (error, sk) {
                    return Text(
                      'Erreur de chargement!\n$error',
                      style: TextStyle(color: AppColors.erreur, fontSize: 13),
                    );
                  },
                  loading: () => Center(
                    child: const CircularProgressIndicator(color: AppColors.or),
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}
