import 'package:aura_estates_core/aura_estates_core.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class ReservationsTable extends StatelessWidget {
  final List<BookingModel> requests;

  const ReservationsTable({super.key, required this.requests});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: AppColors.surfaceElevee,
        borderRadius: BorderRadius.circular(12),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header
          _buildHeader(),
          Divider(color: AppColors.bordure),
          // Rows
          ListView.separated(
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemCount: requests.length,
            separatorBuilder: (_, __) => Divider(color: AppColors.bordure),
            itemBuilder: (context, index) => _buildRow(requests[index]),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      child: Row(
        children: const [
          Expanded(
            flex: 2,
            child: Text(
              'Client',
              style: TextStyle(color: AppColors.textSecondaire),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Propriété',
              style: TextStyle(color: AppColors.textSecondaire),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              'Date souhaitée',
              style: TextStyle(color: AppColors.textSecondaire),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Statut',
              style: TextStyle(color: AppColors.textSecondaire),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRow(BookingModel currentRequest) {
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      child: Row(
        children: [
          Expanded(
            flex: 2,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              spacing: 1,
              children: [
                Text(
                  currentRequest.userName,
                  style: TextStyle(
                    color: AppColors.textPrimaire,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  currentRequest.userMail,
                  style: GoogleFonts.jost(
                    color: AppColors.textDiscret,
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              currentRequest.currentProperty.title,
              style: GoogleFonts.jost(color: AppColors.textPrimaire),
            ),
          ),
          Expanded(
            flex: 2,
            child: Text(
              currentRequest.bookingDate.split(' ')[0],
              style: TextStyle(color: AppColors.textPrimaire),
            ),
          ),
          Expanded(flex: 1, child: _buildBadge('Traitée')),
        ],
      ),
    );
  }

  Widget _buildBadge(String statut) {
    final config =
        {
          'En cours': (AppColors.or.withAlpha(30), AppColors.or),
          'Traitée': (AppColors.succes.withAlpha(30), AppColors.succes),
          'Annulée': (AppColors.erreur.withAlpha(30), AppColors.erreur),
        }[statut] ??
        (AppColors.textDiscret.withAlpha(30), AppColors.textDiscret);

    return Padding(
      padding: const EdgeInsets.only(right: 50),
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(
          color: config.$1,
          borderRadius: BorderRadius.circular(20),
        ),
        child: Center(
          child: Text(
            statut,
            style: TextStyle(
              color: config.$2,
              fontSize: 12,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ),
    );
  }
}
