import 'package:admin/features/auth/presentation/login_screen.dart';
import 'package:admin/features/pages/dashboard/dashboard_page.dart';
import 'package:admin/features/pages/properties/add_property_page.dart';
import 'package:admin/features/pages/properties/edit_property_page.dart';
import 'package:aura_estates_core/aura_estates_core.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'router.g.dart';

// ---------------------------------------------------------
// 1. LE RADAR D'AUTHENTIFICATION
// ---------------------------------------------------------

@riverpod
Stream<User?> authState(Ref ref) {
  return FirebaseAuth.instance.authStateChanges();
}

class RouterNotifier extends ChangeNotifier {
  RouterNotifier(this._ref) {
    _ref.listen(authStateProvider, (_, __) => notifyListeners());
  }
  final Ref _ref;
}

@riverpod
GoRouter router(Ref ref) {
  final notifier = RouterNotifier(ref);
  ref.onDispose(() => notifier.dispose());

  return GoRouter(
    initialLocation: '/dashboard',
    refreshListenable: notifier, // <-- Utilisé directement ici

    redirect: (context, state) {
      final authValue = ref.read(authStateProvider);
      // Attente stoïque pendant le chargement initial
      if (authValue.isLoading) return null;

      final bool isAuth = authValue.value != null;
      final bool isGoingToAuth = state.matchedLocation == '/dashboard';

      // Intrusion bloquée -> Retour au Login
      if (!isAuth && !isGoingToAuth) return '/login';

      // Déj   connecté mais tente d'aller au Login -> Renvoyé au QG
      if (isAuth && isGoingToAuth) return '/dashboard';
      return null; // Passage autorisé
    },

    routes: [
      GoRoute(
        name: 'login',
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        name: 'add_property',
        path: '/add_property',
        builder: (context, state) => const AddPropertyPage(),
      ),
      GoRoute(
        name: 'edit_property',
        path: '/edit_property',

        builder: (context, state) {
          final PropertyModel currentProperty = state.extra as PropertyModel;
          return EditPropertyPage(property: currentProperty);
        },
      ),
      GoRoute(
        name: 'dashboard',
        path: '/dashboard',
        builder: (context, state) => const DashboardPage(),
        routes: [
          /// LA BONNE MÉTHODE : L'ID dans l'URL (Ex: /dashboard/parfum/123)
          // GoRoute(
          //    name: 'parfum_detail',
          //    path: 'parfum/:id',
          //    builder: (context, state) {
          //       final String parfumId = state.pathParameters['id']!;
          //       return ParfumDetailScreen(
          //          id: parfumId,
          //       ); // L'écran se chargera de fetcher l'objet
          //    },
          // ),
        ],
      ),
    ],
  );
}
